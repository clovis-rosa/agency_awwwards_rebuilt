import React from "react";

const CaseStudies = () => {
  return (
    <div className='page'>
      <div className='container'>
        <div className='row'>
          <h3>This is the case studies page</h3>
        </div>
      </div>
    </div>
  );
};

export default CaseStudies;
